# Dummy Image PHP Script
The source code behind [dummyimage.com](http://dummyimage.com) of [Hacker News fame](https://news.ycombinator.com/item?id=1077013).

[http://www.russellheimlich.com/blog/tag/dummyimage.com](http://www.russellheimlich.com/blog/tag/dummyimage.com)